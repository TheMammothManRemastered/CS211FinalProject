to run this demo, run the following two commands in order:

javac @sources
java rootPackage/Main

this demo requires at least jdk 15 to work